# Hamoye_Stage_A_Quiz_Code
This repo contains my solution from FAO United Nation dataset used in Hamoye Stage A Quiz Data Science/Competition 2022 
Below you can find the link to the dataset:

https://github.com/HamoyeHQ/HDSC-Introduction-to-Python-for-machine-learning
